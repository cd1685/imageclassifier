from PIL import Image
import argparse
import numpy as np
import torch


def process_image(image):
    ''' Scales, crops, and normalizes a PIL image for a PyTorch model,
        returns an Numpy array
    '''    
    # TODO: Process a PIL image for use in a PyTorch model
    mean = np.array([0.485, 0.456, 0.406])
    std_d = np.array([0.229, 0.224, 0.225])    
    
    if (image.size[0] > image.size[1]):
        size = image.size[0], 256
    else:
        size = 256, image.size[1]
    
    image.thumbnail(size)
    
    width = image.size[0]
    height = image.size[1]
    new_width = new_height = 224

    left = (width - new_width)/2
    top = (height - new_height)/2
    right = (width + new_width)/2
    bottom = (height + new_height)/2

    image = image.crop((left, top, right, bottom))  
    np_image = np.array(image)
    np_image = np_image / 255
    np_image = (np_image - mean) / std_d    
    np_image = np_image.transpose((2,0,1))

    return torch.from_numpy(np_image)


def predict(image_path, model, topk, use_gpu):
    ''' Predict the class (or classes) of an image using a trained deep learning model.
    '''
#    from PIL import Image    
    #device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    if use_gpu:
        device = "cuda:0"
    else:
        device = "cpu"    
    #device = str(device)
    
    model.to(device)
    # TODO: Implement the code to predict the class from an image file
    model.eval()
    image = Image.open(image_path)
    image = process_image(image).float()
    img = image
    #imshow(image)
    image = image.unsqueeze(0)   
    image = image.to(device)
    
    with torch.no_grad():        
        output = model.forward(image)
                  
        ps = torch.exp(output)
        top_probs, top_indices = ps.topk(topk, dim=1)
        
        top_probs = top_probs.cpu().numpy()[0]
        top_indices  = top_indices.cpu().numpy()[0]

        idx_to_class = {v:k for k, v in model.class_to_idx.items()}
        top_classes = [idx_to_class[x] for x in top_indices]
        
    return top_probs, top_classes



def load_checkpoint(filepath, use_gpu):
    
    #device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    if use_gpu:
        device = "cuda:0"
    else:
        device = "cpu"        
    device = str(device)
    
    checkpoint = torch.load(filepath,map_location=device)
    model = checkpoint['model']
    model.load_state_dict(checkpoint['state_dict'])
    model.class_to_idx = checkpoint['train_index']
    #model.cat_to_name = checkpoint['cat_to_name']
    model.epochs = checkpoint['epochs']
    model.hidden_units = checkpoint['hidden_units']
    model.learn_rate = checkpoint['learn_rate']
    model.input_size = checkpoint['input_size']
    model.output_size = checkpoint['output_size']
    for parameter in model.parameters():
        parameter.requires_grad = False

    model.eval()
    return model


# main execution    
parser = argparse.ArgumentParser()

parser.add_argument("image_path", help="path to image")
parser.add_argument("checkpoint", help="path to checkpoint")
parser.add_argument("--top_k", help="number of top class probabilities to return", type=int, default=1)
parser.add_argument("--category_names", help="Use a mapping of categories to real names (path to JSON object)",
                    default=" ")
parser.add_argument("--gpu", help="flag to tell inference to use GPU", action='store_true')

args = parser.parse_args()

if args.image_path:
    image_path = args.image_path
if args.checkpoint:
    checkpoint = args.checkpoint    
if args.top_k:
    top_k = args.top_k
if args.category_names:
    category_names = args.category_names
if args.gpu:
   use_gpu = True
else:
   use_gpu = False


model = load_checkpoint(checkpoint, use_gpu)

probs, classes = predict(image_path, model, top_k, use_gpu)

float_formatter = lambda x: "%.6f" % x
np.set_printoptions(formatter={'float_kind':float_formatter})
print("probabilties: {}".format(probs))
print("classes: {}".format(classes))

# if category names are present, print the corresponding names as well
if category_names != " ":
    import json
    with open(category_names, 'r') as f:
        cat_to_name = json.load(f)

    names = [cat_to_name[x] for x in classes]
    
    print("names: {}".format(names))