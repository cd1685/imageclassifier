# Imports here
import argparse
import numpy as np
import torch
from torch import nn
from torch import optim
import torch.nn.functional as F
from torchvision import datasets, transforms, models


# Dictionaries to hold data needed for each set of data
datadirs = {}
data_transforms = {}
image_datasets = {}
data_loaders = {}

data_sets = ['train','valid','test']


def load_data(data_dir):  
    #train_dir = data_dir + '/train'
    #valid_dir = data_dir + '/valid'
    #test_dir = data_dir + '/test'
    
    data_transforms['train'] = transforms.Compose([transforms.RandomRotation(30),
                                              transforms.RandomResizedCrop(224),
                                              transforms.RandomHorizontalFlip(),
                                              transforms.ToTensor(),
                                              transforms.Normalize([0.485, 0.456, 0.406], 
                                                                   [0.229, 0.224, 0.225])])

    data_transforms['valid'] = transforms.Compose([transforms.RandomResizedCrop(224),
                                              transforms.ToTensor(),
                                              transforms.Normalize([0.485, 0.456, 0.406], 
                                                                   [0.229, 0.224, 0.225])])

    data_transforms['test'] = transforms.Compose([transforms.RandomResizedCrop(224),
                                             transforms.ToTensor(),
                                             transforms.Normalize([0.485, 0.456, 0.406], 
                                                                  [0.229, 0.224, 0.225])])

    for subset in data_sets:
        datadirs[subset] = data_dir + "/" + subset
        image_datasets[subset] = datasets.ImageFolder(datadirs[subset], transform=data_transforms[subset])
        data_loaders[subset] = torch.utils.data.DataLoader(image_datasets[subset], batch_size=64, shuffle=True)

    #valid_data = datasets.ImageFolder(valid_dir, transform=valid_transforms)
    #test_data = datasets.ImageFolder(test_dir, transform=test_transforms)
    
    #valid_loader = torch.utils.data.DataLoader(valid_data, batch_size=64)
    #test_loader = torch.utils.data.DataLoader(test_data, batch_size=64, shuffle=True)




def train_network(pretrained_model, learn_rate, hidden_units, epochs, use_gpu, save_dir):
    
    model = eval("models."+pretrained_model+"(pretrained=True)")

    # Freeze parameters so we don't backprop through them
    for param in model.parameters():
        param.requires_grad = False

    from collections import OrderedDict
    classifier = nn.Sequential(OrderedDict([
                              ('fc1', nn.Linear(25088, hidden_units)),
                              ('relu1', nn.ReLU()),
                              ('drop1', nn.Dropout(0.3)),
                              ('fc3', nn.Linear(hidden_units, 102)),
                              ('output', nn.LogSoftmax(dim=1))
                              ]))

    model.classifier = classifier

    #device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    if use_gpu:
        device = "cuda:0"
    else:
        device = "cpu"
        
    #print("arch: " + pretrained_model)
    #print("lrate: {}".format(learn_rate))
    #print("hidden units: {}".format(hidden_units))
    #print("epochs: {}".format(epochs))
    #print("using gpu: {}".format(use_gpu))                        
        
    criterion = nn.NLLLoss()

    # Only train the classifier parameters, feature parameters are frozen
    optimizer = optim.Adam(model.classifier.parameters(), lr=learn_rate)

    model.to(device)

    print_every = 40
    steps = 0
    train_losses = []
    test_losses = []
    optimizer.zero_grad()

    for e in range(epochs):
        model.train()
        running_loss = 0
        for inputs, labels in iter(data_loaders['train']):#train_loader):
            steps += 1       
            optimizer.zero_grad()

            # Forward and backward passes
            inputs, labels = inputs.to(device),labels.to(device)
            output = model.forward(inputs)

            loss = criterion(output, labels)
            loss.backward()
            optimizer.step()

            running_loss += loss.item()

            if steps % print_every == 0:
                print("Step: {}".format(steps))

                test_loss = 0
                accuracy = 0
                model.eval()

                with torch.no_grad():
                    for inputs, labels in data_loaders['test']:#test_loader: 
                        inputs, labels = inputs.to(device),labels.to(device)

                        logps = model.forward(inputs)

                        batch_loss = criterion(logps, labels)
                        test_loss += batch_loss.item()

                        ps = torch.exp(logps)
                        equality = (labels.data == ps.max(dim=1)[1])
                        accuracy += equality.type(torch.FloatTensor).mean()                    

                train_losses.append(running_loss/len(data_loaders['train']))#train_loader))
                test_losses.append(test_loss/len(data_loaders['test']))#test_loader))                    
                print(f"Epoch {e+1}/{epochs}.. "
                      f"Train loss: {running_loss/print_every:.3f}.. "
                      f"Test loss: {test_loss/len(data_loaders['test']):.3f}.. "
                      f"Test accuracy: {accuracy/len(data_loaders['test']):.3f}")
                running_loss = 0
                model.train()   

    if save_dir != " ":
        print("Saving checkpoint...")
        checkpoint = {'epochs': epochs,
                      'hidden_units': hidden_units,
                      'learn_rate': learn_rate,
                      'input_size': 25088,
                      'output_size': 102,             
                      'train_index': image_datasets['train'].class_to_idx,
                      #'cat_to_name': cat_to_name,
                      'model': model,
                      'state_dict': model.state_dict(),
                      'optimizer': optimizer.state_dict()}

        torch.save(checkpoint, 'checkpoint.pth')
    

# main execution    
parser = argparse.ArgumentParser()

parser.add_argument("data_dir", help="dataset directory")
parser.add_argument("--save_dir", help="checkpoint save directory", default=" ")
parser.add_argument("--arch", help="architecture for model", default="vgg16")
parser.add_argument("--learning_rate", help="learning rate for model", type=float, default=0.001)
parser.add_argument("--hidden_units", help="number of hidden units for model", type=int, default=4096)
parser.add_argument("--epochs", help="number of epochs for model", type=int, default=6)
parser.add_argument("--gpu", help="flag to tell model to use GPU", action='store_true')

args = parser.parse_args()


if args.data_dir:
    data_dir = args.data_dir
if args.save_dir:
    save_dir = args.save_dir
if args.arch:
   pretrained_model = args.arch
if args.learning_rate:
   learn_rate = args.learning_rate
if args.hidden_units:
   hidden_units = args.hidden_units
if args.epochs:
   epochs = args.epochs
if args.gpu:
   use_gpu = True
else:
   use_gpu = False
    
print("data_dir: " + data_dir)
print("save_dir: " + save_dir)
print("arch: " + pretrained_model)
print("lrate: {}".format(learn_rate))
print("hidden units: {}".format(hidden_units))
print("epochs: {}".format(epochs))
print("using gpu: {}".format(use_gpu))


load_data(data_dir)

#for s in data_sets:
#    print(datadirs[s])
    
train_network(pretrained_model, learn_rate, hidden_units, epochs, use_gpu, save_dir)    